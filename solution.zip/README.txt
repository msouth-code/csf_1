Lauren Diaz & Miayunique South

Contributions:
So far, we contributed equally by pair programming over zoom
